'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const links = [
  { href: '/category/new', label: 'All Games List', icon: '🎮' },
  { href: '/category/hot', label: 'Hot Right Now', icon: '🔥' },
  { href: '/category/dlc', label: 'DLC', icon: '💠' },
  { href: '/category/free', label: 'Free To Play', icon: '🆓' },
  { href: '/category/upcoming', label: 'Coming Soon', icon: '📅' },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex md:flex-col w-[230px] shrink-0 bg-sidebar border-r border-line sticky top-0 h-screen overflow-y-auto py-5">
      <Link href="/" className="flex items-center gap-2 px-5 pb-5 font-display font-bold text-xl">
        NOVA<span className="text-blue-2">PLAY</span>
      </Link>

      <p className="px-5 text-[11px] tracking-wide text-slate-400 mb-2">MAIN MENU</p>

      {links.map((l) => {
        const active = pathname === l.href;
        return (
          <Link
            key={l.href}
            href={l.href}
            className={`flex items-center gap-3 px-5 py-2.5 font-semibold text-sm border-l-2 transition-colors ${
              active
                ? 'text-white border-blue-2 bg-blue-500/10'
                : 'text-slate-400 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            <span>{l.icon}</span>
            {l.label}
          </Link>
        );
      })}

      <Link
        href="/category/upcoming"
        className="block m-4 h-28 rounded-xl border border-line flex items-center justify-center font-display font-bold hover:border-blue-2 transition-colors"
        style={{ background: 'linear-gradient(135deg,#1a2a6c,#0a0e22)' }}
      >
        Pre-Order Now
      </Link>
    </aside>
  );
}
