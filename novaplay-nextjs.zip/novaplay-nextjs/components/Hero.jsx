'use client';

import { motion } from 'framer-motion';
import CharacterCorners from './CharacterCorners';

export default function Hero() {
  return (
    <div
      className="relative mt-5 rounded-2xl overflow-hidden min-h-[280px] flex items-center p-10 border border-line"
      style={{
        background:
          'radial-gradient(60% 90% at 15% 30%, rgba(63,107,255,.5), transparent 60%), radial-gradient(50% 80% at 85% 70%, rgba(255,61,120,.4), transparent 60%), linear-gradient(135deg, #0a0e22, #050710)',
      }}
    >
      <div
        className="absolute inset-0 opacity-50 mix-blend-screen animate-drift"
        style={{
          backgroundImage: 'radial-gradient(rgba(255,255,255,.1) 1.5px, transparent 1.6px)',
          backgroundSize: '14px 14px',
        }}
      />

      <CharacterCorners />

      <div className="relative z-10 max-w-lg">
        <motion.span
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-block bg-pink text-white font-bold px-3 py-1 rounded-full text-sm mb-3.5"
        >
          ⚡ WEEKEND DROP — UP TO 70% OFF
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="font-display font-bold text-3xl md:text-4xl leading-tight mb-3"
        >
          Your next obsession is loading.
        </motion.h1>
        <p className="text-slate-400 mb-5 max-w-md">
          New worlds, legendary comebacks, and the games everyone&apos;s talking about — all in one place.
        </p>
        <a
          href="/category/hot"
          className="inline-flex items-center gap-2 bg-blue hover:bg-blue-2 hover:-translate-y-0.5 transition-all font-display font-bold px-6 py-3 rounded-lg shadow-lg shadow-blue/30"
        >
          Browse Hot Games
        </a>
      </div>
    </div>
  );
}
