import { characters } from '@/lib/games';

export default function CharacterCorners() {
  return (
    <>
      {characters.map((c, i) => (
        <div
          key={c.name}
          className={`hidden md:flex absolute ${c.pos} z-20 flex-col items-center animate-float`}
          style={{ animationDelay: `${i * 0.4}s` }}
        >
          <div className="w-16 h-16 rounded-full border-2 border-dashed border-line bg-black/30 backdrop-blur flex items-center justify-center text-2xl">
            {c.emoji}
          </div>
          <span className="text-[10px] text-pink font-semibold mt-1 whitespace-nowrap">
            {c.name}
          </span>
        </div>
      ))}
    </>
  );
}
