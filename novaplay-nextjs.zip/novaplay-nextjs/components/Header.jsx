'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useCart } from './CartProvider';

const navLinks = [
  { href: '/category/new', label: 'Games' },
  { href: '/category/hot', label: 'PlayStation Plus', gold: true },
  { href: '/category/dlc', label: 'DLC' },
  { href: '/category/free', label: 'Free to Play' },
];

export default function Header() {
  const router = useRouter();
  const [q, setQ] = useState('');
  const { count } = useCart();

  function onSearch(e) {
    e.preventDefault();
    if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`);
  }

  return (
    <header className="sticky top-0 z-50 flex items-center gap-6 px-[4vw] py-3.5 bg-bg/90 backdrop-blur border-b border-line">
      <form
        onSubmit={onSearch}
        className="hidden sm:flex items-center gap-2 bg-panel border border-line rounded-lg px-3 py-2 w-64 text-slate-400"
      >
        <span>🔍</span>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search games..."
          className="bg-transparent outline-none text-white text-sm w-full placeholder:text-slate-500"
        />
      </form>

      <nav className="hidden lg:flex gap-5">
        {navLinks.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className={`font-display font-semibold hover:text-white transition-colors ${
              l.gold ? 'text-gold' : 'text-slate-400'
            }`}
          >
            {l.label}
          </Link>
        ))}
      </nav>

      <div className="flex items-center gap-3 ml-auto">
        <Link
          href="/cart"
          className="relative w-9 h-9 rounded-lg bg-panel border border-line flex items-center justify-center hover:border-blue-2 transition-colors"
        >
          🛒
          {count > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-pink text-white text-[10px] font-bold px-1.5 rounded-full min-w-[16px] text-center">
              {count}
            </span>
          )}
        </Link>
        <div className="w-9 h-9 rounded-full bg-gold flex items-center justify-center">🦆</div>
      </div>
    </header>
  );
}
