'use client';

import { motion } from 'framer-motion';
import { useCart } from './CartProvider';

const badgeStyles = {
  new: 'bg-blue',
  hot: 'bg-pink',
  upcoming: 'bg-gold text-black',
  dlc: 'bg-indigo-500',
  free: 'bg-emerald-500',
};

const badgeLabel = {
  new: 'NEW',
  hot: 'HOT',
  upcoming: 'COMING SOON',
  dlc: 'DLC',
  free: 'FREE',
};

export default function GameCard({ game }) {
  const { dispatch } = useCart();

  return (
    <motion.div
      whileHover={{ y: -6, rotate: -0.4 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className="relative bg-card border border-line rounded-2xl overflow-hidden hover:border-blue-2 hover:shadow-2xl hover:shadow-black/50"
    >
      <div
        className="relative h-40 flex items-center justify-center text-center p-4"
        style={{
          backgroundImage: `${game.gradient}, radial-gradient(circle, rgba(255,255,255,.16) 1.6px, transparent 1.8px)`,
          backgroundSize: 'auto, 11px 11px',
        }}
      >
        <span
          className={`absolute top-2.5 -left-1.5 z-10 font-display font-bold text-[11px] px-3 py-1 rounded-r text-white -rotate-6 shadow ${badgeStyles[game.category]}`}
        >
          {badgeLabel[game.category]}
        </span>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/60" />
        <b className="relative z-10 font-display font-bold text-lg text-white drop-shadow -rotate-2">
          {game.emoji}
          <br />
          {game.title}
        </b>
      </div>

      <div className="p-3.5">
        <h3 className="font-semibold text-sm mb-0.5">{game.title}</h3>
        <p className="text-xs text-slate-400 mb-2">{game.genre}</p>
        <div className="flex items-center justify-between">
          <span className="font-display font-bold text-blue-2">
            {game.price === 0 ? 'Free' : `$${game.price.toFixed(2)}`}
          </span>
          <button
            onClick={() => dispatch({ type: 'ADD', game })}
            className="text-xs font-semibold bg-card2 border border-line rounded-md px-2.5 py-1.5 hover:bg-blue hover:border-blue transition-colors"
          >
            + Add
          </button>
        </div>
      </div>
    </motion.div>
  );
}
