'use client';

export default function FilterBar({
  genres,
  selected,
  onToggle,
  maxPrice,
  priceLimit,
  onPriceChange,
  sort,
  onSortChange,
}) {
  return (
    <div className="flex flex-wrap items-center gap-4 bg-panel border border-line rounded-xl p-4 mb-6">
      <div className="flex flex-wrap gap-2">
        {genres.map((g) => (
          <button
            key={g}
            onClick={() => onToggle(g)}
            className={`text-xs font-semibold px-3 py-1.5 rounded-full border transition-colors ${
              selected.includes(g)
                ? 'bg-blue/20 border-blue-2 text-white'
                : 'bg-transparent border-line text-slate-400 hover:text-white'
            }`}
          >
            {g}
          </button>
        ))}
      </div>

      <label className="flex items-center gap-2 text-xs text-slate-400 ml-auto whitespace-nowrap">
        Max price: ${priceLimit}
        <input
          type="range"
          min="0"
          max={maxPrice}
          value={priceLimit}
          onChange={(e) => onPriceChange(Number(e.target.value))}
        />
      </label>

      <select
        value={sort}
        onChange={(e) => onSortChange(e.target.value)}
        className="bg-card2 border border-line rounded-md text-xs px-2.5 py-1.5 text-white"
      >
        <option value="popular">Popularity</option>
        <option value="price-asc">Price: Low to High</option>
        <option value="price-desc">Price: High to Low</option>
        <option value="name">Name A–Z</option>
      </select>
    </div>
  );
}
