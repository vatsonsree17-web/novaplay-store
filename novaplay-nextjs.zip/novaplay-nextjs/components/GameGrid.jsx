import GameCard from './GameCard';

export default function GameGrid({ games }) {
  if (!games.length) {
    return <p className="text-slate-400 py-10 text-center">No games match your filters.</p>;
  }

  return (
    <div
      className="grid gap-4"
      style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(190px, 1fr))' }}
    >
      {games.map((g) => (
        <GameCard key={g.id} game={g} />
      ))}
    </div>
  );
}
