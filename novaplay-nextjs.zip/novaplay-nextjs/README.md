# NOVAPLAY — Next.js Game Store

A dark blue / black themed game storefront built with **Next.js 14 (App Router)**,
**Tailwind CSS**, and **Framer Motion**.

## Run it

```bash
npm install
npm run dev
```

Then open `http://localhost:3000`.

## What's included

- **`app/page.jsx`** — home page: animated hero banner (with floating character
  artwork pinned to its four corners), New / Hot / Coming Soon rows.
- **`app/category/[slug]/page.jsx`** — real category pages (`/category/new`,
  `/category/hot`, `/category/dlc`, `/category/free`, `/category/upcoming`),
  each with working genre filters, a max-price slider, and a sort dropdown.
- **`app/search/page.jsx`** — live search results page, driven by the search
  bar in the header (`/search?q=...`).
- **`app/cart/page.jsx`** — full cart page: quantity editing, removing items,
  running total, checkout button.
- **`components/CartProvider.jsx`** — global cart state (React Context +
  `useReducer`), persisted to `localStorage` so the cart survives a refresh.
- **`components/Sidebar.jsx`** / **`components/Header.jsx`** — the working
  navigation menus. Every link is a real `next/link` route, not a scroll
  anchor.
- **`components/GameCard.jsx`** — the comic-sticker style game card (halftone
  dot background, rotated ribbon badge, hover lift animation via Framer
  Motion).
- **`lib/games.js`** — all game and character data lives here. Add a new game
  by adding an object to the `games` array — it will automatically show up
  in the right category page.

## Notes

- Styling uses Tailwind's utility classes with a small custom theme
  (`tailwind.config.js`) for the site's colors (`bg`, `sidebar`, `panel`,
  `card`, `blue`, `pink`, `gold`) and two animations (`float`, `drift`).
- Fonts (Rajdhani for display text, Inter for body text) are loaded through
  `next/font/google` in `app/layout.jsx` — no external `<link>` tags needed.
- The cart badge in the header updates instantly from any page because it
  reads from the shared `CartProvider` context.
