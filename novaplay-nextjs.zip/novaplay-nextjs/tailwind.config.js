/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        bg: '#070a17',
        sidebar: '#0a0e22',
        panel: '#0d1230',
        card: '#111633',
        card2: '#151c40',
        line: '#212853',
        blue: {
          DEFAULT: '#3f6bff',
          2: '#7aa2ff',
        },
        pink: '#ff3d78',
        gold: '#ffb020',
      },
      fontFamily: {
        display: ['var(--font-rajdhani)', 'sans-serif'],
        sans: ['var(--font-inter)', 'sans-serif'],
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        drift: {
          '0%': { backgroundPosition: '0 0' },
          '100%': { backgroundPosition: '200px 140px' },
        },
      },
      animation: {
        float: 'float 4s ease-in-out infinite',
        drift: 'drift 14s linear infinite',
      },
    },
  },
  plugins: [],
};
