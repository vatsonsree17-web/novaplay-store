import Hero from '@/components/Hero';
import GameGrid from '@/components/GameGrid';
import { games } from '@/lib/games';

export default function HomePage() {
  const newGames = games.filter((g) => g.category === 'new');
  const hotGames = games.filter((g) => g.category === 'hot');
  const upcomingGames = games.filter((g) => g.category === 'upcoming');

  return (
    <>
      <Hero />

      <section className="pt-10">
        <h2 className="font-display font-bold text-2xl mb-1">Fresh Off the Press</h2>
        <p className="text-slate-400 text-sm mb-4">Just landed this week</p>
        <GameGrid games={newGames} />
      </section>

      <section className="pt-10">
        <h2 className="font-display font-bold text-2xl mb-1">🔥 Hot Right Now</h2>
        <p className="text-slate-400 text-sm mb-4">The community can&apos;t put these down</p>
        <GameGrid games={hotGames} />
      </section>

      <section className="pt-10 pb-6">
        <h2 className="font-display font-bold text-2xl mb-1">Coming Soon</h2>
        <p className="text-slate-400 text-sm mb-4">Wishlist these before launch day</p>
        <GameGrid games={upcomingGames} />
      </section>
    </>
  );
}
