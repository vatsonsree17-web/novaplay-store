'use client';

import { useMemo, useState } from 'react';
import { games, categoryTitles } from '@/lib/games';
import GameGrid from '@/components/GameGrid';
import FilterBar from '@/components/FilterBar';

export default function CategoryPage({ params }) {
  const { slug } = params;
  const base = slug === 'new' ? games : games.filter((g) => g.category === slug);
  const genres = [...new Set(base.map((g) => g.genre))];
  const maxPrice = Math.max(...base.map((g) => g.price), 10);

  const [selectedGenres, setSelectedGenres] = useState([]);
  const [priceLimit, setPriceLimit] = useState(maxPrice);
  const [sort, setSort] = useState('popular');

  function toggleGenre(g) {
    setSelectedGenres((s) => (s.includes(g) ? s.filter((x) => x !== g) : [...s, g]));
  }

  const filtered = useMemo(() => {
    let list = base.filter(
      (g) => g.price <= priceLimit && (selectedGenres.length === 0 || selectedGenres.includes(g.genre))
    );
    if (sort === 'price-asc') list = [...list].sort((a, b) => a.price - b.price);
    if (sort === 'price-desc') list = [...list].sort((a, b) => b.price - a.price);
    if (sort === 'name') list = [...list].sort((a, b) => a.title.localeCompare(b.title));
    if (sort === 'popular') list = [...list].sort((a, b) => b.popularity - a.popularity);
    return list;
  }, [base, selectedGenres, priceLimit, sort]);

  return (
    <div className="pt-8">
      <h1 className="font-display font-bold text-2xl mb-5">
        {categoryTitles[slug] || slug}
      </h1>
      <FilterBar
        genres={genres}
        selected={selectedGenres}
        onToggle={toggleGenre}
        maxPrice={maxPrice}
        priceLimit={priceLimit}
        onPriceChange={setPriceLimit}
        sort={sort}
        onSortChange={setSort}
      />
      <GameGrid games={filtered} />
    </div>
  );
}
