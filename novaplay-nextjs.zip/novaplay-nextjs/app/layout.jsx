import './globals.css';
import { Inter, Rajdhani } from 'next/font/google';
import { CartProvider } from '@/components/CartProvider';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const rajdhani = Rajdhani({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-rajdhani',
});

export const metadata = {
  title: 'NOVAPLAY — Game Store',
  description: 'A dark blue and black themed game storefront, built with Next.js.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${inter.variable} ${rajdhani.variable}`}>
      <body className="bg-bg text-white">
        <CartProvider>
          <div className="flex min-h-screen">
            <Sidebar />
            <div className="flex-1 min-w-0">
              <Header />
              <main className="px-[4vw] pb-16">{children}</main>
            </div>
          </div>
        </CartProvider>
      </body>
    </html>
  );
}
