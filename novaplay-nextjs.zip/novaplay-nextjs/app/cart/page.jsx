'use client';

import Link from 'next/link';
import { useCart } from '@/components/CartProvider';

export default function CartPage() {
  const { items, dispatch, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="pt-16 text-center text-slate-400">
        <p className="mb-4">Your cart is empty.</p>
        <Link
          href="/"
          className="inline-block bg-blue font-display font-bold px-6 py-3 rounded-lg hover:bg-blue-2 transition-colors"
        >
          Browse Games
        </Link>
      </div>
    );
  }

  return (
    <div className="pt-10 max-w-2xl">
      <h1 className="font-display font-bold text-2xl mb-6">Your Cart</h1>

      <div className="space-y-3">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex items-center gap-4 bg-card border border-line rounded-xl p-3.5"
          >
            <div
              className="w-16 h-16 rounded-lg flex items-center justify-center text-2xl shrink-0"
              style={{ background: item.gradient }}
            >
              {item.emoji}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm">{item.title}</h3>
              <span className="text-slate-400 text-xs">
                {item.price === 0 ? 'Free' : `$${item.price.toFixed(2)}`} each
              </span>
            </div>
            <input
              type="number"
              min="1"
              value={item.qty}
              onChange={(e) =>
                dispatch({ type: 'SET_QTY', id: item.id, qty: Number(e.target.value) })
              }
              className="w-14 bg-card2 border border-line rounded-md text-center text-sm py-1"
            />
            <button
              onClick={() => dispatch({ type: 'REMOVE', id: item.id })}
              className="text-xs border border-line rounded-md px-2.5 py-1.5 text-slate-400 hover:text-pink hover:border-pink transition-colors"
            >
              Remove
            </button>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between border-t border-line mt-6 pt-5 text-xl font-bold">
        <span>Total</span>
        <span>${total.toFixed(2)}</span>
      </div>

      <button className="w-full bg-blue hover:bg-blue-2 transition-colors font-display font-bold py-3 rounded-lg mt-4">
        Checkout
      </button>
      <Link
        href="/"
        className="block text-center border border-line rounded-lg py-3 mt-3 hover:border-blue-2 transition-colors"
      >
        Continue Shopping
      </Link>
    </div>
  );
}
