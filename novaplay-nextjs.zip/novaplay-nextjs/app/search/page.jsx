'use client';

import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { games } from '@/lib/games';
import GameGrid from '@/components/GameGrid';

function SearchResults() {
  const params = useSearchParams();
  const q = (params.get('q') || '').toLowerCase();
  const results = games.filter(
    (g) => g.title.toLowerCase().includes(q) || g.genre.toLowerCase().includes(q)
  );

  return (
    <div className="pt-8">
      <h1 className="font-display font-bold text-2xl mb-1">Search results</h1>
      <p className="text-slate-400 text-sm mb-5">
        {results.length} result{results.length !== 1 && 's'} for &quot;{q}&quot;
      </p>
      <GameGrid games={results} />
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<p className="pt-8 text-slate-400">Loading…</p>}>
      <SearchResults />
    </Suspense>
  );
}
